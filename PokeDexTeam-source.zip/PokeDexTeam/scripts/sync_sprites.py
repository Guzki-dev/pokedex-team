#!/usr/bin/env python3
"""Copy front-facing PNG Pokémon sprites into Android assets and generate a manifest.
Source: https://github.com/PokeAPI/sprites (downloaded by the GitHub Actions workflow).
"""
from pathlib import Path
import hashlib, json, shutil, sys

root = Path(__file__).resolve().parents[1]
assets = root / 'app' / 'src' / 'main' / 'assets'
source = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / '.sprite-source' / 'sprites'
target = assets / 'sprites'
if not source.exists():
    raise SystemExit(f'Fonte de sprites não encontrada: {source}')
if target.exists():
    shutil.rmtree(target)
target.mkdir(parents=True)
seen = {}
manifest = []
count = 0
for src in sorted(source.rglob('*.png')):
    rel = src.relative_to(source)
    parts = [x.lower() for x in rel.parts]
    # Only Pokémon sprites; never include backs, item images, trainer portraits or GIF animations.
    if not parts or parts[0] != 'pokemon' or any('back' in part for part in parts):
        continue
    # Numeric canonical files are copied once to their runtime paths below, not again in catalog/.
    if len(rel.parts) == 2 and rel.stem.isdigit():
        continue
    if len(rel.parts) == 3 and rel.parts[1].lower() == 'shiny' and rel.stem.isdigit():
        continue
    # Keep every distinct front-facing collection (normal, shiny, game versions, forms, female variants).
    digest = hashlib.sha256(src.read_bytes()).hexdigest()
    dest_rel = Path('catalog') / rel
    # Preserve the canonical PokeAPI paths used by the app as well as the full source hierarchy.
    dest = target / dest_rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if digest in seen:
        # Duplicate bytes are represented in the manifest by the first copy to avoid storing duplicates.
        manifest.append({'source': rel.as_posix(), 'path': seen[digest], 'sha256': digest, 'duplicate': True})
        continue
    shutil.copy2(src, dest)
    asset_path = dest.relative_to(assets).as_posix()
    seen[digest] = asset_path
    manifest.append({'source': rel.as_posix(), 'path': asset_path, 'sha256': digest, 'duplicate': False})
    count += 1

# Canonical local sprites used throughout the UI (species and shiny IDs).
for folder in ('', 'shiny'):
    src_dir = source / 'pokemon' / folder
    if not src_dir.exists():
        continue
    out_dir = target / 'pokemon' / folder
    out_dir.mkdir(parents=True, exist_ok=True)
    for src in sorted(src_dir.glob('*.png')):
        if not src.stem.isdigit():
            continue
        dest = out_dir / src.name
        digest = hashlib.sha256(src.read_bytes()).hexdigest()
        if digest in seen:
            # Canonical path is required by the UI, so copy even if another catalog image has same bytes.
            pass
        shutil.copy2(src, dest)
        manifest.append({'source': f'pokemon/{folder}/{src.name}' if folder else f'pokemon/{src.name}',
                         'path': dest.relative_to(assets).as_posix(), 'sha256': digest, 'canonical': True})

license_src = source.parent / 'LICENCE.txt'
if license_src.exists():
    shutil.copy2(license_src, assets / 'POKEAPI-SPRITES-LICENCE.txt')

(assets / 'sprite-index.json').write_text(json.dumps({
    'source': 'PokeAPI/sprites', 'source_url': 'https://github.com/PokeAPI/sprites',
    'scope': 'front-facing PNGs only; excludes back sprites and animated GIFs',
    'unique_catalog_files': count, 'entries': manifest
}, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'Sprites frontais copiados: {count}; entradas no índice: {len(manifest)}')
