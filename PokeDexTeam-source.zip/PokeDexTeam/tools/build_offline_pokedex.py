#!/usr/bin/env python3
"""Download and package the PokéAPI National Dex data and sprites into Android assets.
Run from repository root before `gradle assembleDebug`.
"""
import concurrent.futures
import json
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"
DATA = ASSETS / "offline" / "data"
SPRITES = ASSETS / "offline" / "sprites" / "pokemon"
BASE = "https://pokeapi.co/api/v2"
SPRITE_BASE = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon"
MAX_ID = 1025
WORKERS = 12


def request_bytes(url, attempts=5):
    last = None
    for attempt in range(attempts):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "PokeDexTeam-Offline-Pack/1.0 (Android build)"})
            with urllib.request.urlopen(req, timeout=35) as response:
                return response.read()
        except Exception as exc:
            last = exc
            time.sleep(min(1.5 * (attempt + 1), 8))
    raise RuntimeError(f"Failed after {attempts} attempts: {url}: {last}")


def get_json(url):
    return json.loads(request_bytes(url).decode("utf-8"))


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def api_url(resource, ident):
    return f"{BASE}/{resource}/{ident}/"


def fetch_pokemon(pid):
    d = get_json(api_url("pokemon", pid))
    # Keep all fields needed by ficha, moves, ability/type panels, and special forms,
    # while dropping bulky API metadata that the UI never reads.
    compact = {
        "id": d["id"], "name": d["name"], "height": d.get("height", 0), "weight": d.get("weight", 0),
        "species": {"name": d["species"]["name"], "url": d["species"]["url"]},
        "types": d.get("types", []), "stats": d.get("stats", []), "abilities": d.get("abilities", []),
        "moves": [{"move": m["move"], "version_group_details": [
            {"move_learn_method": x["move_learn_method"], "level_learned_at": x.get("level_learned_at", 0), "version_group": x["version_group"]}
            for x in m.get("version_group_details", [])
        ]} for m in d.get("moves", [])],
        "forms": d.get("forms", [])
    }
    write_json(DATA / "pokemon" / f"{pid}.json", compact)
    return d


def fetch_species(pid):
    d = get_json(api_url("pokemon-species", pid))
    compact = {
        "id": d.get("id", pid), "name": d.get("name", ""),
        "is_legendary": d.get("is_legendary", False), "is_mythical": d.get("is_mythical", False),
        "generation": d.get("generation", {}),
        "flavor_text_entries": [{"flavor_text": x.get("flavor_text", ""),
          "language": x.get("language", {}), "version": x.get("version", {})}
          for x in d.get("flavor_text_entries", [])],
        "evolution_chain": d.get("evolution_chain", {}),
        "varieties": d.get("varieties", [])
    }
    write_json(DATA / "species" / f"{pid}.json", compact)
    return d


def download_file(job):
    url, path = job
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = request_bytes(url, attempts=4)
        if not data or len(data) < 50:
            raise RuntimeError("empty or invalid file")
        path.write_bytes(data)
        return True, str(path)
    except Exception as exc:
        return False, f"{url} :: {exc}"


def run_pool(label, jobs, fn, max_workers=WORKERS):
    errors = []
    total = len(jobs)
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(fn, job) for job in jobs]
        for i, future in enumerate(concurrent.futures.as_completed(futures), 1):
            try:
                result = future.result()
                if isinstance(result, tuple) and result and result[0] is False:
                    errors.append(result[1])
                elif result is False:
                    errors.append("unknown error")
            except Exception as exc:
                errors.append(str(exc))
            if i % 100 == 0 or i == total:
                print(f"[{label}] {i}/{total} · falhas: {len(errors)}", flush=True)
    return errors


def main():
    for folder in [DATA / "pokemon", DATA / "species", DATA / "abilities", DATA / "types", DATA / "evolutions", SPRITES, SPRITES / "shiny"]:
        folder.mkdir(parents=True, exist_ok=True)

    print("Baixando dados oficiais da PokéAPI para o pacote offline…", flush=True)
    pokemon_jobs = list(range(1, MAX_ID + 1))
    pokemon_errors = run_pool("Pokémon", pokemon_jobs, lambda pid: (True, str(DATA / "pokemon" / f"{pid}.json")) if (DATA / "pokemon" / f"{pid}.json").exists() else (fetch_pokemon(pid) and True, str(pid)))
    species_errors = run_pool("Espécies", pokemon_jobs, lambda pid: (True, str(DATA / "species" / f"{pid}.json")) if (DATA / "species" / f"{pid}.json").exists() else (fetch_species(pid) and True, str(pid)))

    # Build index and gather unique related resources from downloaded compact JSON.
    index = []
    abilities, types, evolution_urls = set(), set(), {}
    for pid in pokemon_jobs:
        pp = DATA / "pokemon" / f"{pid}.json"
        sp = DATA / "species" / f"{pid}.json"
        if not pp.exists() or not sp.exists():
            continue
        p = json.loads(pp.read_text(encoding="utf-8"))
        s = json.loads(sp.read_text(encoding="utf-8"))
        index.append({"name": p["name"], "id": pid, "url": f"{BASE}/pokemon-species/{pid}/"})
        for a in p.get("abilities", []):
            abilities.add(a["ability"]["name"])
        for t in p.get("types", []):
            types.add(t["type"]["name"])
        eurl = s.get("evolution_chain", {}).get("url")
        if eurl:
            try:
                eid = int(eurl.rstrip("/").split("/")[-1])
                evolution_urls[eid] = eurl
            except ValueError:
                pass
    write_json(DATA / "pokemon-index.json", {"count": len(index), "results": index})
    if len(index) < MAX_ID:
        raise RuntimeError(f"Pacote incompleto: só {len(index)}/{MAX_ID} Pokémon disponíveis; interrompendo build para não gerar APK incompleto.")

    related_jobs = []
    for name in sorted(abilities):
        related_jobs.append((f"{BASE}/ability/{name}", DATA / "abilities" / f"{name}.json"))
    for name in sorted(types):
        related_jobs.append((f"{BASE}/type/{name}", DATA / "types" / f"{name}.json"))
    for eid, url in evolution_urls.items():
        related_jobs.append((url, DATA / "evolutions" / f"{eid}.json"))

    def related_job(job):
        url, path = job
        if path.exists():
            return True, str(path)
        d = get_json(url)
        if "/ability/" in url:
            compact = {"name": d.get("name"), "flavor_text_entries": d.get("flavor_text_entries", []), "effect_entries": d.get("effect_entries", [])}
        elif "/type/" in url:
            compact = {"name": d.get("name"), "damage_relations": d.get("damage_relations", {}), "pokemon": d.get("pokemon", [])}
        else:
            compact = d
        write_json(path, compact)
        return True, str(path)

    related_errors = run_pool("Habilidades/tipos/evoluções", related_jobs, related_job)
    if related_errors:
        raise RuntimeError(f"Falha ao baixar dados relacionados: {related_errors[:3]}")

    print("Baixando sprites normais e Shiny…", flush=True)
    sprite_jobs = []
    for pid in pokemon_jobs:
        sprite_jobs.append((f"{SPRITE_BASE}/{pid}.png", SPRITES / f"{pid}.png"))
        sprite_jobs.append((f"{SPRITE_BASE}/shiny/{pid}.png", SPRITES / "shiny" / f"{pid}.png"))
    sprite_errors = run_pool("Sprites", sprite_jobs, download_file, max_workers=20)
    # Shiny files missing from upstream fall back to the corresponding local normal sprite
    # so no ficha has a broken image while offline; manifest records these fallbacks.
    fallback_ids = []
    for pid in pokemon_jobs:
        shiny = SPRITES / "shiny" / f"{pid}.png"
        normal = SPRITES / f"{pid}.png"
        if not shiny.exists() and normal.exists():
            shutil.copyfile(normal, shiny)
            fallback_ids.append(pid)
    missing_normal = [pid for pid in pokemon_jobs if not (SPRITES / f"{pid}.png").exists()]
    if missing_normal:
        raise RuntimeError(f"Sprites normais ausentes para {len(missing_normal)} espécies; interrompendo build.")

    manifest = {
        "national_dex_count": len(index), "max_id": MAX_ID,
        "normal_sprites": MAX_ID, "shiny_sprites": MAX_ID,
        "shiny_fallback_to_normal": fallback_ids,
        "missing_shiny_upstream": len(fallback_ids),
        "data_source": "PokéAPI v2; sprites from PokeAPI/sprites GitHub repository",
        "offline_bundle_generated_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    }
    write_json(ASSETS / "offline" / "manifest.json", manifest)
    total_bytes = sum(p.stat().st_size for p in (ASSETS / "offline").rglob("*") if p.is_file())
    print(f"Pacote pronto: {len(index)} Pokémon, {MAX_ID} sprites normais, {MAX_ID} sprites Shiny/fallback; {total_bytes/1024/1024:.1f} MiB.", flush=True)
    if pokemon_errors or species_errors:
        print(f"Aviso: erros recuperados/ignorados nos downloads de Pokémon={len(pokemon_errors)}, espécies={len(species_errors)}", flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERRO AO GERAR PACOTE OFFLINE: {exc}", file=sys.stderr)
        sys.exit(1)
